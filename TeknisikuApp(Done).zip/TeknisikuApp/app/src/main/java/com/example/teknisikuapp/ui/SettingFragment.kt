package com.example.teknisikuapp.ui

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.edit
import androidx.fragment.app.Fragment
import com.example.teknisikuapp.LoginActivity
import com.example.teknisikuapp.R

class SettingFragment : Fragment(R.layout.fragment_setting) {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPreferences = requireActivity().getSharedPreferences("settings", Context.MODE_PRIVATE)

        val logoutButton: ImageView = view.findViewById(R.id.imageView_logout)
        logoutButton.setOnClickListener {
            performLogout()
        }
    }

    private fun performLogout() {
        val sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE)
        sharedPreferences.edit {
            clear()
            apply()
        }

        val intent = Intent(requireActivity(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)

        Toast.makeText(requireContext(), "Logged out", Toast.LENGTH_SHORT).show()
    }
}
