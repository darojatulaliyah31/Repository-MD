package com.example.teknisikuapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.teknisikuapp.api.ApiService
import com.example.teknisikuapp.model.Recommendation
import com.example.teknisikuapp.model.RecommendationResponse
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class DetailServiceActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var serviceNameTextView: TextView
    private lateinit var serviceDescriptionTextView: TextView
    private lateinit var serviceImageView: ImageView
    private lateinit var serviceRatingTextView: TextView
    private lateinit var reviewItemContainer: LinearLayout

    private lateinit var mMap: GoogleMap
    private var recommendationLocation: LatLng? = null

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api-native-444210.et.r.appspot.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService: ApiService = retrofit.create(ApiService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_service)

        serviceNameTextView = findViewById(R.id.namaTempatService)
        serviceDescriptionTextView = findViewById(R.id.deskripsiToko)
        serviceImageView = findViewById(R.id.imageToko)
        serviceRatingTextView = findViewById(R.id.ratingValue)
        reviewItemContainer = findViewById(R.id.reviewItemContainer)

        val latitude = intent.getDoubleExtra("LATITUDE", 0.0)
        val longitude = intent.getDoubleExtra("LONGITUDE", 0.0)
        recommendationLocation = LatLng(latitude, longitude)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        if (latitude != 0.0 && longitude != 0.0) {
            fetchRecommendations(latitude, longitude)
        }
    }

    private fun fetchRecommendations(latitude: Double, longitude: Double) {
        apiService.getRecommendations(latitude, longitude).enqueue(object : Callback<RecommendationResponse> {
            override fun onResponse(call: Call<RecommendationResponse>, response: Response<RecommendationResponse>) {
                if (response.isSuccessful) {
                    val recommendations = response.body()?.recommendations
                    if (recommendations != null && recommendations.isNotEmpty()) {
                        val recommendation = recommendations[0]

                        serviceNameTextView.text = recommendation.id
                        serviceDescriptionTextView.text = recommendation.description
                        serviceRatingTextView.text = recommendation.rating

                        Glide.with(this@DetailServiceActivity)
                            .load(recommendation.image)
                            .into(serviceImageView)

                        reviewItemContainer.removeAllViews()
                        for (review in recommendations) {
                            addReviewToLayout(review)
                        }

                        recommendationLocation = LatLng(recommendation.location._latitude, recommendation.location._longitude)
                        updateMapLocation()
                    }
                } else {
                    Toast.makeText(this@DetailServiceActivity, "Failed to load recommendations", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<RecommendationResponse>, t: Throwable) {
                Toast.makeText(this@DetailServiceActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun addReviewToLayout(recommendation: Recommendation) {
        val reviewTextView = TextView(this)
        reviewTextView.text = recommendation.review
        reviewItemContainer.addView(reviewTextView)
    }

    private fun updateMapLocation() {
        recommendationLocation?.let { location ->
            mMap.addMarker(MarkerOptions().position(location).title("Service Location"))
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        updateMapLocation()
    }
}
