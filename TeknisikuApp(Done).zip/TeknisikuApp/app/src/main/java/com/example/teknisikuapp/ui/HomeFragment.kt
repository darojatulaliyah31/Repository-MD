package com.example.teknisikuapp.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.teknisikuapp.R
import com.example.teknisikuapp.adapter.ServiceAdapter
import com.example.teknisikuapp.api.ApiConfig
import com.example.teknisikuapp.model.RecommendationResponse
import com.example.teknisikuapp.utils.GeocodingService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var serviceAdapter: ServiceAdapter
    private lateinit var searchBar: EditText
    private lateinit var clearTextIcon: ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        searchBar = view.findViewById(R.id.searchBar)
        clearTextIcon = view.findViewById(R.id.clearTextIcon)
        clearTextIcon.setOnClickListener {
            searchBar.text.clear()
            clearTextIcon.visibility = View.GONE
            serviceAdapter = ServiceAdapter(emptyList())
            recyclerView.adapter = serviceAdapter
        }

        searchBar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val city = s.toString()
                if (city.isNotEmpty()) {
                    clearTextIcon.visibility = View.VISIBLE
                } else {
                    clearTextIcon.visibility = View.GONE
                    serviceAdapter = ServiceAdapter(emptyList())
                    recyclerView.adapter = serviceAdapter
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        searchBar.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                val city = searchBar.text.toString()
                if (city.isNotEmpty()) {
                    fetchCoordinatesAndData(city)
                }
                true
            } else {
                false
            }
        }
    }

    private fun fetchCoordinatesAndData(city: String) {
        GeocodingService.getCoordinates(requireContext(), city, object : GeocodingService.CoordinatesCallback {
            override fun onSuccess(latitude: Double, longitude: Double) {
                fetchDataFromApi(latitude, longitude)
            }

            override fun onFailure(error: String) {
                if (searchBar.text.isNotEmpty()) {
                    showError("Failed to get coordinates: $error")
                }
            }
        })
    }

    private fun fetchDataFromApi(latitude: Double, longitude: Double) {
        val client = ApiConfig.getApiService().getRecommendations(latitude, longitude)
        client.enqueue(object : Callback<RecommendationResponse> {
            override fun onResponse(
                call: Call<RecommendationResponse>,
                response: Response<RecommendationResponse>
            ) {
                if (response.isSuccessful) {
                    val data = response.body()?.recommendations
                    if (data != null) {
                        serviceAdapter = ServiceAdapter(data)
                        recyclerView.adapter = serviceAdapter
                    }
                } else {
                    showError("Failed to fetch data")
                }
            }

            override fun onFailure(call: Call<RecommendationResponse>, t: Throwable) {
                showError("Failed to fetch data: ${t.message}")
            }
        })
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}
