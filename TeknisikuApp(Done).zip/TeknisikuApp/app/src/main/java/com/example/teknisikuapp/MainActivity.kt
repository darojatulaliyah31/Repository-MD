package com.example.teknisikuapp

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.annotation.SuppressLint
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.example.teknisikuapp.ui.HomeFragment
import com.example.teknisikuapp.ui.FavoriteFragment
import com.example.teknisikuapp.ui.SettingFragment
import com.example.teknisikuapp.ui.SolusiFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private var currentFragmentTag: String? = null
    private val LOCATION_PERMISSION_REQUEST_CODE = 1
    private val locationReceiver = LocationReceiver()
    private var locationDialog: AlertDialog? = null

    private lateinit var homeFragment: HomeFragment
    private lateinit var favoriteFragment: FavoriteFragment
    private lateinit var solusiFragment: SolusiFragment
    private lateinit var settingFragment: SettingFragment

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lastKnownLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = getSharedPreferences("theme_prefs", MODE_PRIVATE)
        applySavedTheme()
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        setupBottomNavigation()

        if (savedInstanceState == null) {
            homeFragment = HomeFragment()
            favoriteFragment = FavoriteFragment()
            solusiFragment = SolusiFragment()
            settingFragment = SettingFragment()
            loadFragment(homeFragment, "HomeFragment")
            findViewById<BottomNavigationView>(R.id.bottom_navigation).selectedItemId = R.id.nav_home
        } else {
            homeFragment = supportFragmentManager.findFragmentByTag("HomeFragment") as HomeFragment
            favoriteFragment = supportFragmentManager.findFragmentByTag("FavoriteFragment") as FavoriteFragment
            solusiFragment = supportFragmentManager.findFragmentByTag("SolusiFragment") as SolusiFragment
            settingFragment = supportFragmentManager.findFragmentByTag("SettingFragment") as SettingFragment
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!isLocationEnabled()) {
            showPermissionDialog()
        } else {
            requestLocationPermission()
        }

        val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
        filter.addAction(Intent.ACTION_PROVIDER_CHANGED)
        registerReceiver(locationReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(locationReceiver)
    }

    private fun setupBottomNavigation() {
        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    loadFragment(homeFragment, "HomeFragment")
                    true
                }
                R.id.nav_favorite -> {
                    loadFragment(favoriteFragment, "FavoriteFragment")
                    true
                }
                R.id.nav_solusi -> {
                    loadFragment(solusiFragment, "SolusiFragment")
                    true
                }
                R.id.nav_setting -> {
                    loadFragment(settingFragment, "SettingFragment")
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment, tag: String): Boolean {
        if (currentFragmentTag != tag) {
            val transaction = supportFragmentManager.beginTransaction()
            supportFragmentManager.findFragmentByTag(tag)?.let {
                transaction.show(it)
            } ?: run {
                transaction.add(R.id.container, fragment, tag)
            }
            currentFragmentTag?.let { oldTag ->
                supportFragmentManager.findFragmentByTag(oldTag)?.let { oldFragment ->
                    transaction.hide(oldFragment)
                }
            }
            transaction.commit()
            currentFragmentTag = tag
        }
        return true
    }

    private fun applySavedTheme() {
        val isDarkMode = sharedPreferences.getBoolean("dark_mode", false)
        AppCompatDelegate.setDefaultNightMode(
            if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun showPermissionDialog() {
        locationDialog?.dismiss()
        locationDialog = AlertDialog.Builder(this)
            .setTitle("Izinkan Akses Lokasi")
            .setMessage("Aplikasi ini memerlukan akses lokasi Anda. Layanan optimal. Harap aktifkan GPS untuk melanjutkan.")
            .setPositiveButton("Aktifkan") { _, _ ->
                if (!isLocationEnabled()) {
                    promptEnableLocation()
                } else {
                    requestLocationPermission()
                }
            }
            .setCancelable(false)
            .create()

        locationDialog?.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)

        locationDialog?.show()
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun promptEnableLocation() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivity(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getLastKnownLocation()
            } else {
                if (!isLocationEnabled()) {
                    showPermissionDialog()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLastKnownLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestLocationPermission()
            return
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    lastKnownLocation = location
                    updateHomeFragmentLocation()
                }
            }
    }

    private fun updateHomeFragmentLocation() {
        val location = lastKnownLocation
        if (location != null) {
            val bundle = Bundle()
            bundle.putDouble("latitude", location.latitude)
            bundle.putDouble("longitude", location.longitude)
            homeFragment.arguments = bundle
        }
    }

    inner class LocationReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == LocationManager.PROVIDERS_CHANGED_ACTION) {
                if (isLocationEnabled()) {
                    locationDialog?.dismiss()
                    getLastKnownLocation()
                } else {
                    showPermissionDialog()
                }
            }
        }
    }
}
