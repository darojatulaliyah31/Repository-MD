package com.example.teknisikuapp.model

data class Solution(
    val id: String,
    val solution: String
)

data class SolutionResponse(
    val status: String,
    val solutions: List<Solution>? = null,
    val solutionData: Solution? = null
)

data class Recommendation(
    val id: String,
    val description: String,
    val image: String?,
    val location: Location,
    val rating: String,
    val review: String
)

data class Location(
    val _latitude: Double,
    val _longitude: Double
)

data class RecommendationResponse(
    val recommendations: List<Recommendation>
)

data class SignupRequest(
    val fullName: String,
    val email: String,
    val phoneNumber: String,
    val password: String
)

data class SignupResponse(
    val message: String
)

data class LoginRequest(
    val fullName: String,
    val password: String
)

data class LoginResponse(
    val message: String,
    val user: User
)

data class User(
    val favorites: List<String>,
    val fullName: String,
    val email: String,
    val phoneNumber: String,
    val password: String
)

data class GoogleAuthRequest(
    val email: String,
    val fullName: String,
    val phoneNumber: String
)

data class GoogleAuthResponse(
    val message: String
)

data class FavoriteRequest(
    val email: String,
    val serviceId: String
)

data class FavoriteResponse(
    val message: String,
    val favorites: List<String>
)