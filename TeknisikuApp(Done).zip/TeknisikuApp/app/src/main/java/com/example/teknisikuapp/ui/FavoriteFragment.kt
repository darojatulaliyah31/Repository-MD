package com.example.teknisikuapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.teknisikuapp.R
import com.example.teknisikuapp.adapter.FavoriteAdapter
import com.example.teknisikuapp.model.Location
import com.example.teknisikuapp.model.Recommendation

class FavoriteFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_favorite, container, false)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val favoriteServices = listOf(
            Recommendation("1", "AA COM", "https://storage.cloud.google.com/foto-tempat-service/foto-tempat-servis-surabaya/3AA%20Com.jpg?authuser=1", Location(0.0, 0.0), "5", "Review 1"),
            Recommendation("2", "AA.COM - Simo Jawar", "https://storage.cloud.google.com/foto-tempat-service/foto-tempat-servis-surabaya/22AA.COM%20-%20Simo%20Jawar.jpg?authuser=1", Location(0.0, 0.0), "4", "Review 2"),
            Recommendation("3", "AB Computer", "https://storage.cloud.google.com/foto-tempat-service/foto-tempat-service-yogyakarta/AB%20Computer.png?authuser=1", Location(0.0, 0.0), "3", "Review 3")
        )

        val adapter = FavoriteAdapter(favoriteServices)
        recyclerView.adapter = adapter

        return view
    }
}
