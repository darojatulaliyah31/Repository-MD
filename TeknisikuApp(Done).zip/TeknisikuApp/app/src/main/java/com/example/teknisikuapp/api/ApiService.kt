package com.example.teknisikuapp.api

import com.example.teknisikuapp.model.FavoriteRequest
import com.example.teknisikuapp.model.FavoriteResponse
import com.example.teknisikuapp.model.GoogleAuthRequest
import com.example.teknisikuapp.model.GoogleAuthResponse
import com.example.teknisikuapp.model.LoginRequest
import com.example.teknisikuapp.model.LoginResponse
import com.example.teknisikuapp.model.RecommendationResponse
import com.example.teknisikuapp.model.SignupRequest
import com.example.teknisikuapp.model.SignupResponse
import com.example.teknisikuapp.model.SolutionResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("/")
    fun getEndpoint(): Call<String>

    @POST("/api/users/signup")
    fun signup(@Body signupRequest: SignupRequest): Call<SignupResponse>

    @POST("/api/users/login")
    fun login(@Body loginRequest: LoginRequest): Call<LoginResponse>

    @GET("/api/solutions")
    fun getAllSolutions(): Call<SolutionResponse>

    @GET("/api/solutions/{id}")
    fun getSolutionById(@Path("id") id: String): Call<SolutionResponse>

    @GET("/api/recommendations")
    fun getRecommendations(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double
    ): Call<RecommendationResponse>

    @POST("/api/users/google-auth")
    fun googleAuth(
        @Body googleAuthRequest: GoogleAuthRequest
    ): Call<GoogleAuthResponse>

    @POST("/api/favorites")
    fun addOrRemoveFavorite(
        @Body favoriteRequest: FavoriteRequest
    ): Call<FavoriteResponse>

    @GET("/api/favorites/{email}")
    fun getFavorites(
        @Path("email") email: String
    ): Call<FavoriteResponse>
}