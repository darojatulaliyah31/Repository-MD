package com.example.teknisikuapp

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.teknisikuapp.api.ApiService
import com.example.teknisikuapp.model.Solution
import com.example.teknisikuapp.model.SolutionResponse
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import android.text.Layout
import androidx.core.text.HtmlCompat

class DetailSolusiActivity : AppCompatActivity() {

    private lateinit var apiService: ApiService
    private lateinit var solutionDescriptionTextView: TextView
    private lateinit var solutionSubTitleTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_solusi)

        solutionSubTitleTextView = findViewById(R.id.subTitle)
        solutionDescriptionTextView = findViewById(R.id.solusiDeskripsi)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://api-native-444210.et.r.appspot.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()
            )
            .build()

        apiService = retrofit.create(ApiService::class.java)

        val solutionId = intent.getStringExtra("solution_id")
        if (solutionId != null) {
            fetchSolutions(solutionId)
        } else {
            Toast.makeText(this, "Solution ID is missing", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchSolutions(solutionId: String) {
        val call = apiService.getAllSolutions()
        call.enqueue(object : Callback<SolutionResponse> {
            override fun onResponse(call: Call<SolutionResponse>, response: Response<SolutionResponse>) {
                if (response.isSuccessful) {
                    val solutions = response.body()?.solutions
                    if (solutions != null) {
                        val solution = solutions.find { it.id == solutionId }
                        if (solution != null) {
                            Log.d("SolutionDetails", "Solution ID: ${solution.id}, Description: ${solution.solution}")
                            solutionSubTitleTextView.text = solution.id

                            val formattedSolution = """
                                <ol>
                                    ${solution.solution.split("\n").joinToString("") { "<li>$it</li>" }}
                                </ol>
                            """.trimIndent()

                            solutionDescriptionTextView.text = HtmlCompat.fromHtml(formattedSolution, HtmlCompat.FROM_HTML_MODE_LEGACY)
                            solutionDescriptionTextView.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
                            solutionDescriptionTextView.setLineSpacing(1.5f, 1.0f)
                            solutionDescriptionTextView.setPadding(16, 16, 16, 16)
                        } else {
                            solutionSubTitleTextView.text = "No solution details available."
                            solutionDescriptionTextView.text = "No solution details available."
                        }
                    } else {
                        showToast("No solutions found")
                    }
                } else {
                    showToast("Failed to load solutions")
                }
            }

            override fun onFailure(call: Call<SolutionResponse>, t: Throwable) {
                showToast("Error: ${t.message}")
            }
        })
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
