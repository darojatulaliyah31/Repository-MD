package com.example.teknisikuapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.teknisikuapp.DetailSolusiActivity
import com.example.teknisikuapp.R
import com.example.teknisikuapp.adapter.SolusiAdapter
import com.example.teknisikuapp.api.ApiService
import com.example.teknisikuapp.model.Solution
import com.example.teknisikuapp.model.SolutionResponse
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class SolusiFragment : Fragment() {

    private lateinit var apiService: ApiService
    private lateinit var adapter: SolusiAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_solusi, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://api-native-444210.et.r.appspot.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()
            )
            .build()

        apiService = retrofit.create(ApiService::class.java)

        fetchSolutions()

        return view
    }

    private fun fetchSolutions() {
        val call = apiService.getAllSolutions()
        call.enqueue(object : Callback<SolutionResponse> {
            override fun onResponse(call: Call<SolutionResponse>, response: Response<SolutionResponse>) {
                if (response.isSuccessful) {
                    val solutions = response.body()?.solutions ?: emptyList()
                    adapter = SolusiAdapter(solutions) { solution ->
                        val intent = Intent(context, DetailSolusiActivity::class.java)
                        intent.putExtra("solution_id", solution.id)
                        startActivity(intent)
                    }
                    recyclerView.adapter = adapter
                } else {
                    Toast.makeText(context, "Failed to load solutions", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<SolutionResponse>, t: Throwable) {
                Toast.makeText(context, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
