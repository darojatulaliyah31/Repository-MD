package com.example.teknisikuapp.utils

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.util.Locale

object GeocodingService {

    interface CoordinatesCallback {
        fun onSuccess(latitude: Double, longitude: Double)
        fun onFailure(error: String)
    }

    fun getCoordinates(context: Context, cityName: String, callback: CoordinatesCallback) {
        val handler = Handler(Looper.getMainLooper())
        Thread {
            try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val addresses: List<Address>? = geocoder.getFromLocationName(cityName, 1)
                if (addresses != null && addresses.isNotEmpty()) {
                    val address = addresses[0]
                    handler.post {
                        callback.onSuccess(address.latitude, address.longitude)
                    }
                } else {
                    handler.post {
                        callback.onFailure("Tempat Service Berhasil di Temukan")
                    }
                }
            } catch (e: IOException) {
                handler.post {
                    callback.onFailure("Kesalahan jaringan atau layanan geocoding")
                }
            }
        }.start()
    }
}
