package com.example.teknisikuapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.teknisikuapp.R
import com.example.teknisikuapp.model.Solution

class SolusiAdapter(
    private val solusiList: List<Solution>,
    private val onItemClicked: (Solution) -> Unit
) : RecyclerView.Adapter<SolusiAdapter.SolusiViewHolder>() {

    class SolusiViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(R.id.textView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SolusiViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_solusi, parent, false)
        return SolusiViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: SolusiViewHolder, position: Int) {
        val solusi = solusiList[position]
        holder.textView.text = solusi.id
        holder.itemView.setOnClickListener {
            onItemClicked(solusi)
        }
    }

    override fun getItemCount(): Int {
        return solusiList.size
    }
}
