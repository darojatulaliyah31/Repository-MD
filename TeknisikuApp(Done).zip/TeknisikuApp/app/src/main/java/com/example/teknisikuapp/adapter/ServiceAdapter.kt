package com.example.teknisikuapp.adapter

import android.content.Intent
import android.location.Geocoder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.teknisikuapp.DetailServiceActivity
import com.example.teknisikuapp.R
import com.example.teknisikuapp.model.Recommendation
import java.util.Locale

class ServiceAdapter(private val serviceList: List<Recommendation>) :
    RecyclerView.Adapter<ServiceAdapter.ServiceViewHolder>() {

    class ServiceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val logo: ImageView = itemView.findViewById(R.id.logo)
        val namaToko: TextView = itemView.findViewById(R.id.namaToko)
        val lokasiToko: TextView = itemView.findViewById(R.id.lokasiToko)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServiceViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recommendation, parent, false)
        return ServiceViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ServiceViewHolder, position: Int) {
        val service = serviceList[position]

        Glide.with(holder.itemView.context)
            .load(service.image)
            .into(holder.logo)

        holder.namaToko.text = service.id

        val geocoder = Geocoder(holder.itemView.context, Locale.getDefault())
        val addresses = geocoder.getFromLocation(service.location._latitude, service.location._longitude, 1)
        val cityName = addresses?.firstOrNull()?.locality ?: "Unknown Location"

        holder.lokasiToko.text = cityName

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailServiceActivity::class.java).apply {
                putExtra("LATITUDE", service.location._latitude)
                putExtra("LONGITUDE", service.location._longitude)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return serviceList.size
    }
}
