package com.example.teknisikuapp.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.teknisikuapp.DetailServiceActivity
import com.example.teknisikuapp.R
import com.example.teknisikuapp.model.Recommendation

class FavoriteAdapter(private val favoriteList: List<Recommendation>) :
    RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    class FavoriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageTokoService: ImageView = itemView.findViewById(R.id.imageTokoService)
        val textTokoService: TextView = itemView.findViewById(R.id.namaTokoService)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_service, parent, false)
        return FavoriteViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val favorite = favoriteList[position]

        Glide.with(holder.itemView.context)
            .load(favorite.image)
            .into(holder.imageTokoService)

        holder.textTokoService.text = favorite.description

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailServiceActivity::class.java)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return favoriteList.size
    }
}
